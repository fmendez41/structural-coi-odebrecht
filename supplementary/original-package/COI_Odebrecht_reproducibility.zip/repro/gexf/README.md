# GEXF Files — Odebrecht Colombia Network Analysis

## Structure

### 00_originales/
Original GEXF files from /mnt/project/, as received. No entity resolution applied.
- `Gch1.gexf` — pre-2010 period (Uribe era, adjudication of Ruta del Sol II)
- `Gch2.gexf` — 2010–2014 (Santos I, legal-stability contract and Ocaña–Gamarra)
- `Gch3.gexf` — 2014–2016 (Santos II, transaction contract and NHMN's appointment)
- `Gch4.gexf` — 2016–2019+ (judicialization under FGN headed by NHMN)
- `Gch2OttoB.gexf` — Satellite subnetwork (Otto Bula's offshore laundering circuit)

Note: The /mnt/project/ folder also contains dated versions (e.g., `20230411-Gch1.gexf`) which are earlier snapshots of the same networks and are not included here to avoid confusion.

### 01_clean_v3/
Entity-resolved networks (155 canonical nodes total across the four period networks).
13 duplicate labels merged (e.g., ODB → Odebrecht, AIdeaki → AHideaki, EliasVidal → BernardoNElias),
1 node excluded (EduardoBueno). See `clasificacion_nodos_v3.csv` for the full node classification.

### 02_enriched_v2/
Institutionally enriched versions of Gch3 and Gch4. Adds:
- 2 event nodes: `Terna2016` (presidential shortlist), `DemandaNulidad2019` (electoral nullity petition)
- 7 documented edges anchored in [dejusticia2019demanda]:
  - Terna2016—NHMN, Terna2016—CSJ, Terna2016—PresidenciaJMSC
  - NHMN—CSJ (Acuerdo 871 of 11 July 2016)
  - DemandaNulidad2019—ConsejoEstado, DemandaNulidad2019—NHMN, DemandaNulidad2019—CSJ

This is the version used for headline results in the paper.
The v1 (documentary baseline) is used for sensitivity analysis in Table 12 of the paper.

### Files
| File | Nodes | Edges | Notes |
|---|---|---|---|
| Gch1_clean.gexf | 73 | 128 | pre-2010 |
| Gch2_clean.gexf | 130 | 243 | 2010–14 |
| Gch2OttoB_clean.gexf | ~32 | ~31 | 2010–14 satellite |
| Gch3_clean.gexf | 108 | 221 | 2014–16 (v1) |
| Gch3_v2.gexf | 109 | 225 | 2014–16 (v2, +Terna2016) |
| Gch4_clean.gexf | 114 | 276 | 2016–19+ (v1) |
| Gch4_v2.gexf | 116 | 283 | 2016–19+ (v2, +Terna2016, DemandaNulidad2019) |

### Node attributes (in all _clean and _v2 files)
- `tipo`: persona / institucion / empresa / vehiculo / objeto / evento
- `esfera`: publico / privado / instrumental / dual / objeto
- `bloque`: Estado / Aval / Odebrecht / NHMN / Politicos / Intermediarios / Offshore / Proyecto / Solarte / Contexto

### Classification files
- `clasificacion_nodos_v3.csv` — 155 canonical nodes with attributes
- `clasificacion_nodos_v4.csv` — 157 nodes (v3 + Terna2016 + DemandaNulidad2019)
- `sensibilidad_v1_v2.csv` — v1 vs v2 comparison of headline metrics
