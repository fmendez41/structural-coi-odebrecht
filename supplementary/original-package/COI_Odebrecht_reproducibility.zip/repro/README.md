# Reproducibility package — COI–Odebrecht paper

**Quantifying Conflict of Interest as a Precursor of Corruption:
A Temporal Network Analysis of the Odebrecht Case in Colombia**

Andrés Felipe Méndez-Arenas, MSc. · ORCID [0009-0002-4183-6472](https://orcid.org/0009-0002-4183-6472) · afmendez@protonmail.com

This package contains everything needed to regenerate every metric, table
and figure reported in the paper: the period networks (GEXF), the node
classification (CSV), and the Python scripts.

## Requirements

```
python >= 3.10
networkx >= 3.0
numpy
matplotlib
```

```bash
pip install networkx numpy matplotlib
```

## Contents

```
gexf/
  00_originales/        5 raw GEXF files as first reconstructed (Gephi exports)
  01_clean_v3/          after entity resolution (169 raw labels → 155 canonical
                        nodes; 13 merges, 1 exclusion) = documentary baseline v1
  02_enriched_v2/       institutionally enriched v2: adds the event nodes
                        Terna2016 and DemandaNulidad2019 plus 7 documented
                        edges anchored in the electoral-nullity petition
  clasificacion_nodos_v3.csv   node classification for v1 (155 nodes)
  clasificacion_nodos_v4.csv   node classification for v2 (157 nodes):
                               node, tipo, esfera, bloque, presencia,
                               persistente_4redes, nota (documentary referent)
  sensibilidad_v1_v2.csv       v1 vs v2 sensitivity of headline results
  README.md                    details of the GEXF layers

codigo/
  coi_lib.py                   shared library: all framework metrics
  01_overview_metrics.py       Table 2  — network overview and temporal dynamics
  02_detection_coi.py          Table 3  — Stage 1 unsupervised detection (COI index)
  03_p1_trajectory.py          Table 4  + Fig 10 — P1 broker position
  04_p2_knockout.py            Table 5  + Fig 11 — P2 comparative knockout
  05_p3_group_betweenness.py   Table 6  — P3 group-restricted betweenness
  06_p4_ego_stability.py       Table 7  + Fig 12 — P4 sphere-split ego stability
  07_p5_vehicle_accretion.py   Table 8  + Fig 13 — P5 instrumental accretion
  08_p2b_group_dependence.py   Table 10 + Fig 15 — P2b institutional capture
  09_p6_suppression.py         Table 11 + Fig 16 — P6 selective suppression
  10_link_prediction.py        Table 12 — the negative result (precision@K)
  11_conduit_facilitator.py    Table 9  + Fig 14 — conduit vs facilitator (§5.3.6)
  12_network_figures.py        Figs 1–9 + Appendix Figs A1–A5 (network plots)

figuras/                       output directory (figures regenerate here)
```

## Running

Each script is standalone and prints the table it reproduces; figures are
written to `figuras/`:

```bash
cd codigo
python3 02_detection_coi.py       # fast
python3 06_p4_ego_stability.py    # fast
python3 04_p2_knockout.py         # ~1 min
python3 09_p6_suppression.py      # ~2 min (6,387 dyads)
python3 12_network_figures.py     # ~5 min (14 plots)
```

Headline analyses run on v2 (`02_enriched_v2/`); `10_link_prediction.py`
runs on the documentary baseline v1, as in the paper, because the v2
additions are institutional facts known ex post.

## Verified reproduction

Checked against the published GEXF files (exact unless noted):

| Paper item | Script | Status |
|---|---|---|
| Table 2 (n, m, density, H, ⟨C⟩, Q) | 01 | exact |
| Table 3 (COI 0.00→3.16→6.00→7.35; 2.1×; OttoB 4.47; GGM 3.46) | 02 | exact |
| Table 7 (J: 0.60/0.00 · 0.90/0.00/0.00 · 1.00/0.40/0.50) | 06 | exact |
| Table 12 (K=22/8/49; PA lift 5×; all else 0) | 10 | exact |
| Table 4 (percentiles 83.6/93.1/99.1/98.3; P 0.500→0.720) | 03 | exact |
| Table 6 (NHMN inter-bloc share; FGN leads 2016-19+) | 05 | exact |
| Table 9 conduit/facilitator contrast | 11 | exact |
| Table 10 (instances 56.6% vs 56.2%; Δ eff −15.3% exact) | 08 | < 1 pp (path-enumeration ties) |
| Table 11 (FGN–ODB rank 2, FGN–CSJ 4, FGN–CFC **8 of 6,387**; LCSG dist 3, 0 common nbrs) | 09 | headline ranks exact; deep-tail ranks among RA=0 ties vary by tie order |
| Table 5 Δ efficiency (−4.01 … +0.05 … −3.36) | 04 | exact |
| Table 13 v1 knockout (+10.0% / +11.7%) | 04 (on v1) | exact |
| Table 5 v2 Δ distance | 04 | **see note** |

**Convention note (knockout Δ distance, v2).** The scripts implement one
common protocol — mean geodesic distance over directed source–target
instances, unreachable pairs skipped — for every actor. On the released
v2 file this yields **+13.3 %** for NHMN alone (+14.9 % ego-cluster);
the paper's Table 5 reports +11.4 % (+13.1 %) from the original
computation. The paper itself flags this in the caption of Table 9
("+13.3 % vs. +11.4 % owing to this convention"). The ranking of actors
and the two-orders-of-magnitude contrast with every comparable are
invariant to the convention; Δ efficiency and the v1 column reproduce
exactly.

Louvain community detection is seeded (`seed=42`); participation
coefficients and modularity may vary in the second decimal under a
different seed or NetworkX version, as noted in §6.9 (robustness across
community-detection algorithms).

## Provenance pipeline

```
documentary sources ──► 00_originales (Gephi)
        │  entity resolution (clasificacion_nodos_v3.csv)
        ▼
01_clean_v3  (v1, 155 canonical nodes)
        │  + Terna2016, DemandaNulidad2019, 7 edges (petition-anchored)
        ▼
02_enriched_v2  (v2, 157 nodes; headline analyses)
```

The entity-resolution merge map is documented in `gexf/README.md` and in
the `nota` column of the classification CSVs; Appendix A of the paper is
generated directly from `clasificacion_nodos_v4.csv`.
